# fsdata_maker
make fsdata file with perl script
just write in the console :
perl makefsdata.pl
